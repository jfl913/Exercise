
#import <UIKit/UIKit.h>

@interface OAuthLoginViewController : UIViewController

@property (strong, nonatomic) NSString *userToken;

@end
