//
//  ByteClubTests.m
//  ByteClubTests
//
//  Created by Charlie Fulton on 7/24/13.
//  Copyright (c) 2013 Razeware. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface ByteClubTests : XCTestCase

@end

@implementation ByteClubTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
